<?php
session_start();
include(__DIR__ . '/config.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("SELECT u.id AS user_id, u.password_hash, p.id AS player_id, p.name 
    FROM users u
    JOIN players p ON p.user_id = u.id
    WHERE u.email = :email");
    $stmt->execute([$_POST['username']]);
    $user = $stmt->fetch();

    if ($user && password_verify($_POST['password'], $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header('Location: ../dashboard.php');
    } else {
        echo "Invalid credentials.";
    }
   error_log("Test debug: user tried to login with " . $_POST['username']);
 
}
?>


